package com.uepb.lexer.exceptions;

public class ProgramReadException extends RuntimeException{
    
    public ProgramReadException(String message){
        super(message);
    }

}
