package com.uepb;

public class SemanticException extends RuntimeException{
    
    public SemanticException(String message){
        super(message);
    }

}
